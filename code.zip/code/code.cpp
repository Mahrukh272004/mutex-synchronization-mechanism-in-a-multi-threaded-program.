#include <iostream>
#include <pthread.h>
#include <unistd.h>
using namespace std;

pthread_mutex_t mutex;
pthread_cond_t canCross;

int currentDir = 2;
int numCarsOnBridge = 0;
int numBusesOnBridge = 0;


void ExitTheBridge()
{
    cout << "All vehicles have left" << endl;
    currentDir = 2;
    numCarsOnBridge = 0;
    numBusesOnBridge = 0;
}

// Function to manage vehicles arriving at the bridge
void ArriveAtBridge(int dir, char type)
{
    pthread_mutex_lock(&mutex);

    // Wait until its safe for the vehicle to cross the bridge
    while ((type == 'b' && (numBusesOnBridge > 0 || numCarsOnBridge > 2)) ||
           (type == 'c' && numCarsOnBridge > 3))
    {
        pthread_cond_wait(&canCross, &mutex);
    }

    // Update bridge status based on the arriving vehicle
    currentDir = dir;
    if (type == 'b')
    {
        numBusesOnBridge++;
    }
    else
    {
        numCarsOnBridge++;
    }


    cout << "Vehicle " << type << " arrived on bridge. Direction: " << currentDir << endl;

    pthread_mutex_unlock(&mutex);
}

// Thread function representing a vehicle
void *ThreadFunc(void *p)
{
    char (*vehicle)[2] = (char (*)[2])p;
    char type = (*vehicle)[0];
    int dir = static_cast<int>((*vehicle)[1]) - 48;

    // Vehicle arrives at the bridge
    ArriveAtBridge(dir, type);

    // Simulate time for crossing the bridge
    sleep(2);

    pthread_mutex_lock(&mutex);

    // Update bridge status when the vehicle leaves
    if (type == 'b')
    {
        numBusesOnBridge--;
    }
    else
    {
        numCarsOnBridge--;
    }


    cout << endl;
    cout << "Vehicle " << type << " leaving bridge. Direction: " << currentDir << endl;

    // Signal that the bridge is available
    pthread_cond_broadcast(&canCross);

    pthread_mutex_unlock(&mutex);

    return NULL;
}

int main()
{
cout<<"Start"<<endl;
cout<<"Bus : b"<<endl;
cout<<"Car : c"<<endl;
    // Initialize mutex and condition variable
    pthread_mutex_init(&mutex, NULL);
    pthread_cond_init(&canCross, NULL);

    // Array representing vehicles and their directions
    char vehicle[10][2] = {{'c', '0'}, {'c', '1'}, {'c', '0'}, {'b', '1'}, {'c', '1'}, {'b', '1'}, {'b', '1'}, {'c', '0'}, {'b', '1'}, {'b', '1'}};

    // Array to store thread IDs
    pthread_t thread[10];

    // Create threads for each vehicle
    for (int i = 0; i < 10; i++)
    {
        sleep(1);
        pthread_create(&thread[i], NULL, &ThreadFunc, (void *)&vehicle[i]);
    }

    // Allow some time for threads to start
    sleep(1);

    // Join all threads to wait for their completion
    for (int i = 0; i < 10; i++)
        pthread_join(thread[i], NULL);

    // Additional delay to ensure all threads finish before calling ExitTheBridge
    sleep(2);

    // Reset bridge-related variables
    ExitTheBridge();

    // Destroy mutex and condition variable
    pthread_mutex_destroy(&mutex);
    pthread_cond_destroy(&canCross);

    return 0;
}

